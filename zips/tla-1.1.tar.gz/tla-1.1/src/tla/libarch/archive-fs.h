/* archive-fs.h:
 *
 ****************************************************************
 * Copyright (C) 2003 Tom Lord
 *
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__LIBARCH__ARCHIVE_FS_H
#define INCLUDE__LIBARCH__ARCHIVE_FS_H


#include "tla/libarch/archive.h"





/* automatically generated __STDC__ prototypes */
extern void arch_fs_make_archive (t_uchar * name, t_uchar * target_path, t_uchar * version, t_uchar * mirror_of, int dot_listing_lossage);
extern void arch_fs_archive_connect (struct arch_archive ** arch);
extern void arch_fs_update_listing_file (t_uchar * dir);
#endif  /* INCLUDE__LIBARCH__ARCHIVE_FS_H */


/* tag: Tom Lord Sat Jan  5 15:26:10 2002 (archive-fs.h)
 */
