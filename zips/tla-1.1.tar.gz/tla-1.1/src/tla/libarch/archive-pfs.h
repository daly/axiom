/* archive-pfs.h:
 *
 ****************************************************************
 * Copyright (C) 2003 Tom Lord
 *
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__LIBARCH__ARCHIVE_PFS_H
#define INCLUDE__LIBARCH__ARCHIVE_PFS_H


#include "tla/libarch/archive.h"


/* automatically generated __STDC__ prototypes */
extern void arch_pfs_make_archive (t_uchar * name, t_uchar *location, t_uchar * version, t_uchar * mirror_of, int dot_listing_lossage);
extern void arch_pfs_archive_connect (struct arch_archive ** a);
#endif  /* INCLUDE__LIBARCH__ARCHIVE_PFS_H */


/* tag: Tom Lord Sat Jan  5 15:26:10 2002 (archive-pfs.h)
 */
