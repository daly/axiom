/* piw-variables.h -
 *
 ****************************************************************
 * Copyright (C) 1999 Tom Lord
 * 
 * See the file "COPYING.PIW" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__PIW_VARIABLES_H
#define INCLUDE__PIW__PIW_VARIABLES_H

extern int piw_malloc_log;
extern int piw_malloc_block_pad;
extern int piw_malloc_block_fill;
extern int piw_malloc_padding_fill;
extern int piw_malloc_check_filled;
extern int piw_malloc_internals_check;
extern int piw_log_writes;
extern int piw_keep_tag_bits;
extern int piw_tag_map_range;
extern int piw_log_buffer_size;


/* automatically generated __STDC__ prototypes */
extern void piw_init_flags_and_variables ();
#endif  /* INCLUDE__PIW__PIW_VARIABLES_H */

