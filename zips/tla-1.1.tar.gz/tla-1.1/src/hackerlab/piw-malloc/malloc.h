/* malloc.h - PIW replacement for <malloc.h>
 *
 ****************************************************************
 * Copyright (C) 1998 Tom Lord
 * 
 * See the file "COPYING.PIW" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__MALLOC_H
#define INCLUDE__PIW__MALLOC_H

/* A synonym for libc-malloc.h
 */

#include "hackerlab/piw-malloc/libc-malloc.h"


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__PIW__MALLOC_H */

