/* This file is generated automatically by (piw log-cogen).
 * Do not edit it.
 */

struct piw_malloc_data /* record-type: malloc */
{
  int call_number;
  int amt_requested;
  void * new_block;
};

struct piw_realloc_data /* record-type: realloc */
{
  int call_number;
  void * block;
  int amt_requested;
  void * new_block;
};

struct piw_free_data /* record-type: free */
{
  int call_number;
  void * block;
};

struct piw_malloc_call_data /* record-type: malloc_call */
{
  int call_number;
  int amt_requested;
  unsigned long caller_address;
};

struct piw_realloc_call_data /* record-type: realloc_call */
{
  int call_number;
  void * block;
  int amt_requested;
  unsigned long caller_address;
};

struct piw_free_call_data /* record-type: free_call */
{
  int call_number;
  void * block;
  unsigned long caller_address;
};

struct piw_bogus_realloc_data /* record-type: bogus_realloc */
{
  int call_number;
  void * location;
};

struct piw_bogus_free_data /* record-type: bogus_free */
{
  int call_number;
  void * location;
};

struct piw_bogus_malloc_padding_data /* record-type: bogus_malloc_padding */
{
  void * block;
  void * location;
};

struct piw_bogus_malloc_fill_data /* record-type: bogus_malloc_fill */
{
  void * block;
  void * location;
};

struct piw_bogus_malloc_meta_data_data /* record-type: bogus_malloc_meta_data */
{
  void * location;
};

struct piw_malloc_tags_map_overflow_data /* record-type: malloc_tags_map_overflow */
{
};

struct piw_block_write_data /* record-type: block_write */
{
  void * location;
  void * origin;
  int size;
};

struct piw_block_read_data /* record-type: block_read */
{
  void * location;
  void * origin;
  int size;
};

struct piw_bad_block_write_data /* record-type: bad_block_write */
{
  void * location;
  void * origin;
  int size;
};

struct piw_bad_block_read_data /* record-type: bad_block_read */
{
  void * location;
  void * origin;
  int size;
};

struct piw_rm_data /* record-type: rm */
{
  void * location;
  int size;
};

struct piw_wm_data /* record-type: wm */
{
  void * location;
  int size;
};

struct piw_bad_write_data /* record-type: bad_write */
{
  void * location;
  int size;
};

struct piw_bad_read_data /* record-type: bad_read */
{
  void * location;
  int size;
};

struct piw_init_data /* record-type: init */
{
  int pid;
};

struct piw_sequence_data /* record-type: sequence */
{
  int seq;
};

struct piw_stray_write_data /* record-type: stray_write */
{
  void * location;
};

extern void piw_log_malloc (int amt_requested, void * new_block);
extern void piw_log_realloc (void * block, int amt_requested, void * new_block);
extern void piw_log_free (void * block);
extern void piw_log_malloc_call (int amt_requested);
extern void piw_log_realloc_call (void * block, int amt_requested);
extern void piw_log_free_call (void * block);
extern void piw_log_bogus_realloc (void * location);
extern void piw_log_bogus_free (void * location);
extern void piw_log_bogus_malloc_padding (void * block, void * location);
extern void piw_log_bogus_malloc_fill (void * block, void * location);
extern void piw_log_bogus_malloc_meta_data (void * location);
extern void piw_log_malloc_tags_map_overflow ();
extern void piw_log_block_write (void * location, void * origin, int size);
extern void piw_log_block_read (void * location, void * origin, int size);
extern void piw_log_bad_block_write (void * location, void * origin, int size);
extern void piw_log_bad_block_read (void * location, void * origin, int size);
extern void piw_log_rm (void * location, int size);
extern void piw_log_wm (void * location, int size);
extern void piw_log_bad_write (void * location, int size);
extern void piw_log_bad_read (void * location, int size);
extern void piw_log_init (int pid);
extern void piw_log_sequence (int seq);
extern void piw_log_stray_write (void * location);
