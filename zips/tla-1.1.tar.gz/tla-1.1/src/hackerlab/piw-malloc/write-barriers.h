/* write-barriers.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING.PIW" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__WRITE_BARRIERS_H
#define INCLUDE__PIW__WRITE_BARRIERS_H

extern struct piw_watchpt
{
  void * start;
  void * end;
} piw_watchpt[2];


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__PIW__WRITE_BARRIERS_H */
