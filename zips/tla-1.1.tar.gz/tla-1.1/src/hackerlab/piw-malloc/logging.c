/* This file is generated automatically by (piw log-cogen).
 * Do not edit it.
 */

#include "hackerlab/piw/log.h"
#include "hackerlab/piw-malloc/logging.h"


static int calls_to_malloc = 0;
static int calls_to_realloc = 0;
static int calls_to_free = 0;


void
piw_log_malloc (int amt_requested, void * new_block)
{
  struct piw_malloc_data data;
  data.call_number = calls_to_malloc++;
  data.amt_requested = amt_requested;
  data.new_block = new_block;
  piw_log("malloc", (void *)&data, sizeof (data));
}

void
piw_log_realloc (void * block, int amt_requested, void * new_block)
{
  struct piw_realloc_data data;
  data.call_number = calls_to_realloc++;
  data.block = block;
  data.amt_requested = amt_requested;
  data.new_block = new_block;
  piw_log("realloc", (void *)&data, sizeof (data));
}

void
piw_log_free (void * block)
{
  struct piw_free_data data;
  data.call_number = calls_to_free++;
  data.block = block;
  piw_log("free", (void *)&data, sizeof (data));
}

void
piw_log_malloc_call (int amt_requested)
{
  struct piw_malloc_call_data data;
  data.call_number = calls_to_malloc;
  data.amt_requested = amt_requested;
  data.caller_address = 0;
  piw_log("malloc_call", (void *)&data, sizeof (data));
}

void
piw_log_realloc_call (void * block, int amt_requested)
{
  struct piw_realloc_call_data data;
  data.call_number = calls_to_realloc;
  data.block = block;
  data.amt_requested = amt_requested;
  data.caller_address = 0;
  piw_log("realloc_call", (void *)&data, sizeof (data));
}

void
piw_log_free_call (void * block)
{
  struct piw_free_call_data data;
  data.call_number = calls_to_free;
  data.block = block;
  data.caller_address = 0;
  piw_log("free_call", (void *)&data, sizeof (data));
}

void
piw_log_bogus_realloc (void * location)
{
  struct piw_bogus_realloc_data data;
  data.call_number = calls_to_realloc;
  data.location = location;
  piw_log("bogus_realloc", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_bogus_free (void * location)
{
  struct piw_bogus_free_data data;
  data.call_number = calls_to_free;
  data.location = location;
  piw_log("bogus_free", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_bogus_malloc_padding (void * block, void * location)
{
  struct piw_bogus_malloc_padding_data data;
  data.block = block;
  data.location = location;
  piw_log("bogus_malloc_padding", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_bogus_malloc_fill (void * block, void * location)
{
  struct piw_bogus_malloc_fill_data data;
  data.block = block;
  data.location = location;
  piw_log("bogus_malloc_fill", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_bogus_malloc_meta_data (void * location)
{
  struct piw_bogus_malloc_meta_data_data data;
  data.location = location;
  piw_log("bogus_malloc_meta_data", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_malloc_tags_map_overflow ()
{
  struct piw_malloc_tags_map_overflow_data data;
  piw_log("malloc_tags_map_overflow", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_block_write (void * location, void * origin, int size)
{
  struct piw_block_write_data data;
  data.location = location;
  data.origin = origin;
  data.size = size;
  piw_log("block_write", (void *)&data, sizeof (data));
}

void
piw_log_block_read (void * location, void * origin, int size)
{
  struct piw_block_read_data data;
  data.location = location;
  data.origin = origin;
  data.size = size;
  piw_log("block_read", (void *)&data, sizeof (data));
}

void
piw_log_bad_block_write (void * location, void * origin, int size)
{
  struct piw_bad_block_write_data data;
  data.location = location;
  data.origin = origin;
  data.size = size;
  piw_log("bad_block_write", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_bad_block_read (void * location, void * origin, int size)
{
  struct piw_bad_block_read_data data;
  data.location = location;
  data.origin = origin;
  data.size = size;
  piw_log("bad_block_read", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_rm (void * location, int size)
{
  struct piw_rm_data data;
  data.location = location;
  data.size = size;
  piw_log("rm", (void *)&data, sizeof (data));
}

void
piw_log_wm (void * location, int size)
{
  struct piw_wm_data data;
  data.location = location;
  data.size = size;
  piw_log("wm", (void *)&data, sizeof (data));
}

void
piw_log_bad_write (void * location, int size)
{
  struct piw_bad_write_data data;
  data.location = location;
  data.size = size;
  piw_log("bad_write", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_bad_read (void * location, int size)
{
  struct piw_bad_read_data data;
  data.location = location;
  data.size = size;
  piw_log("bad_read", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_init (int pid)
{
  struct piw_init_data data;
  data.pid = pid;
  piw_log("init", (void *)&data, sizeof (data));
  piw_flush_log ();
}

void
piw_log_sequence (int seq)
{
  struct piw_sequence_data data;
  data.seq = seq;
  piw_log("sequence", (void *)&data, sizeof (data));
}

void
piw_log_stray_write (void * location)
{
  struct piw_stray_write_data data;
  data.location = location;
  piw_log("stray_write", (void *)&data, sizeof (data));
  piw_flush_log ();
}

