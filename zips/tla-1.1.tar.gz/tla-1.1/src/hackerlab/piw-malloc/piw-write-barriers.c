

#define PIW_EXTERN_INLINE
#define PIW_CHECK_WRITES
#define PIW_WATCHPOINTS
#include "piw-write-barriers.h"
