/* This file is generated automatically by (piw log-cogen).
 * Do not edit it.
 */

struct piw_malloc_data;
void piw_text_log_malloc(int fd, struct piw_malloc_data *);
struct piw_realloc_data;
void piw_text_log_realloc(int fd, struct piw_realloc_data *);
struct piw_free_data;
void piw_text_log_free(int fd, struct piw_free_data *);
struct piw_malloc_call_data;
void piw_text_log_malloc_call(int fd, struct piw_malloc_call_data *);
struct piw_realloc_call_data;
void piw_text_log_realloc_call(int fd, struct piw_realloc_call_data *);
struct piw_free_call_data;
void piw_text_log_free_call(int fd, struct piw_free_call_data *);
struct piw_bogus_realloc_data;
void piw_text_log_bogus_realloc(int fd, struct piw_bogus_realloc_data *);
struct piw_bogus_free_data;
void piw_text_log_bogus_free(int fd, struct piw_bogus_free_data *);
struct piw_bogus_malloc_padding_data;
void piw_text_log_bogus_malloc_padding(int fd, struct piw_bogus_malloc_padding_data *);
struct piw_bogus_malloc_fill_data;
void piw_text_log_bogus_malloc_fill(int fd, struct piw_bogus_malloc_fill_data *);
struct piw_bogus_malloc_meta_data_data;
void piw_text_log_bogus_malloc_meta_data(int fd, struct piw_bogus_malloc_meta_data_data *);
struct piw_malloc_tags_map_overflow_data;
void piw_text_log_malloc_tags_map_overflow(int fd, struct piw_malloc_tags_map_overflow_data *);
struct piw_block_write_data;
void piw_text_log_block_write(int fd, struct piw_block_write_data *);
struct piw_block_read_data;
void piw_text_log_block_read(int fd, struct piw_block_read_data *);
struct piw_bad_block_write_data;
void piw_text_log_bad_block_write(int fd, struct piw_bad_block_write_data *);
struct piw_bad_block_read_data;
void piw_text_log_bad_block_read(int fd, struct piw_bad_block_read_data *);
struct piw_rm_data;
void piw_text_log_rm(int fd, struct piw_rm_data *);
struct piw_wm_data;
void piw_text_log_wm(int fd, struct piw_wm_data *);
struct piw_bad_write_data;
void piw_text_log_bad_write(int fd, struct piw_bad_write_data *);
struct piw_bad_read_data;
void piw_text_log_bad_read(int fd, struct piw_bad_read_data *);
struct piw_init_data;
void piw_text_log_init(int fd, struct piw_init_data *);
struct piw_sequence_data;
void piw_text_log_sequence(int fd, struct piw_sequence_data *);
struct piw_stray_write_data;
void piw_text_log_stray_write(int fd, struct piw_stray_write_data *);


typedef void (*formatter_fn)();

extern struct piw_formatter
{
  t_uchar * name;
  formatter_fn fn;
} piw_formatters[];

