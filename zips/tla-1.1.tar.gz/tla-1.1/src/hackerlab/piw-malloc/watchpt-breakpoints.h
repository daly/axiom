/* watchpt-breakpoints.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING.PIW" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__WATCHPT_BREAKPOINTS_H
#define INCLUDE__PIW__WATCHPT_BREAKPOINTS_H



/* automatically generated __STDC__ prototypes */
extern void * piw_watchpt0_breakpoint (void * addr, int length);
extern void * piw_watchpt1_breakpoint (void * addr, int length);
#endif  /* INCLUDE__PIW__WATCHPT_BREAKPOINTS_H */
