/* tag: Tom Lord Tue Dec  4 14:41:29 2001 (exit.c)
 */
/* exit.c -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */


#include "hackerlab/os/exit.h"



