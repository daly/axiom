/* tag: Tom Lord Tue Dec  4 14:41:30 2001 (stdarg.h)
 */
/* stdarg.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__OS__STDARG_H
#define INCLUDE__OS__STDARG_H


#include <stdarg.h>


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__OS__STDARG_H */
