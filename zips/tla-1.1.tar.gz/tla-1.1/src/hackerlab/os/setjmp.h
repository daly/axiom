/* tag: Tom Lord Tue Dec  4 14:41:30 2001 (setjmp.h)
 */
/* setjmp.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__OS__SETJMP_H
#define INCLUDE__OS__SETJMP_H



#include <setjmp.h>


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__OS__SETJMP_H */
