/* tag: Tom Lord Tue Dec  4 14:41:29 2001 (param.h)
 */
/* param.h -
 *
 ****************************************************************
 * Copyright (C) 2001 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__SYS__PARAM_H
#define INCLUDE__SYS__PARAM_H

#include <sys/param.h>


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__SYS__PARAM_H */
