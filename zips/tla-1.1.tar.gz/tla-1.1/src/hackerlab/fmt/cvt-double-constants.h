/* tag: Tom Lord Tue Dec  4 14:41:27 2001 (cvt-double-constants.h)
 */
/* This file is generated automatically by "variable-cogen".
 * Do not edit it.
 */

enum base100_constants
{
  powers_table_frequency = 32,
  pow2_base100_non_expt = -1088 - 1,
  pow2_base100_min_expt = -1088,
  pow2_base100_max_expt = 992,
};
