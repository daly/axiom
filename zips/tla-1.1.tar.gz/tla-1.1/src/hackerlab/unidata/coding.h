/* tag: Tom Lord Tue Dec  4 14:41:49 2001 (coding.h)
 */
/* coding.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__UNIDATA__CODING_H
#define INCLUDE__UNIDATA__CODING_H


#include "hackerlab/uni/coding.h"


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__UNIDATA__CODING_H */
