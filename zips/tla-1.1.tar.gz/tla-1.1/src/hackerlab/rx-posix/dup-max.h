/* tag: Tom Lord Tue Dec  4 14:41:39 2001 (dup-max.h)
 */
/* dup-max.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__RX_POSIX__DUP_MAX_H
#define INCLUDE__RX_POSIX__DUP_MAX_H



#define RX_DUP_MAX 255



/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__RX_POSIX__DUP_MAX_H */
