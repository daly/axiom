/* regex.h - posix compatibility header file
 *
 ****************************************************************
 * Copyright (C) 1998, 2000 Thomas Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */



#ifndef INCLUDE__RX_POSIX__REGEX_H
#define INCLUDE__RX_POSIX__REGEX_H



#include "hackerlab/rx-posix/posix.h"


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__RX_POSIX__REGEX_H */
