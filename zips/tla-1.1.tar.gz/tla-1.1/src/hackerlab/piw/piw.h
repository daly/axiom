/* tag: Tom Lord Tue Dec  4 14:41:50 2001 (piw.h)
 */
/* piw.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING.PIW" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__PIW_H
#define INCLUDE__PIW__PIW_H

#include "hackerlab/piw/gdb.h"
#include "hackerlab/piw/log.h"
#include "hackerlab/piw/variables.h"


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__PIW__PIW_H */
