/* tag: Tom Lord Tue Dec  4 14:41:51 2001 (piw.c)
 */
/* piw.c -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */


#include "hackerlab/piw/piw.h"



