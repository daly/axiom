/* tag: Tom Lord Tue Dec  4 14:41:51 2001 (gdb.h)
 */
/* gdb.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING.PIW" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__GDB_H
#define INCLUDE__PIW__GDB_H


#include "hackerlab/machine/types.h"


/* automatically generated __STDC__ prototypes */
extern void piw_msg_breakpoint (t_uchar * msg);
extern void piw_breakpoint (void);
#endif  /* INCLUDE__PIW__GDB_H */
