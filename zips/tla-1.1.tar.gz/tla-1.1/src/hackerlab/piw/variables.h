/* variables.h - decls for setting control variables from the environment
 *
 * author(s): Tom Lord
 ****************************************************************
 * Copyright (C) 1998 UUNET Technologies, Inc.
 *
 * See the file "COPYING.PIW" for further information
 * about the copyright status of this work.
 */

#ifndef INCLUDE__PIW__VARIABLES_H
#define INCLUDE__PIW__VARIABLES_H



#include "hackerlab/machine/types.h"


/* automatically generated __STDC__ prototypes */
extern unsigned int piw_get_flag (t_uchar * name);
#endif  /* INCLUDE__PIW__VARIABLES_H */
