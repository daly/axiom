/* log.h - generic decls for generating PIW log entries
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__PIW__LOG_H
#define INCLUDE__PIW__LOG_H



/* automatically generated __STDC__ prototypes */
extern void piw_log (char * record_name, void * data, int record_length);
extern void piw_flush_log (void);
#endif  /* INCLUDE__PIW__LOG_H */
